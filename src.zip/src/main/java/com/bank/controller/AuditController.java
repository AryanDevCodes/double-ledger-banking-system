package com.bank.controller;

import com.bank.dto.audit.AuditLogEntryDTO;
import com.bank.dto.audit.AuditLogPageResponseDTO;
import com.bank.exception.InvalidDataException;
import com.bank.service.audit.AuditService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/audit")
@RequiredArgsConstructor
@Slf4j
public
class AuditController {
  private final AuditService auditService;
  private static final int MAX_PAGE_SIZE = 200;

  @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_AUDITOR')")
  @GetMapping("/logs")
  public ResponseEntity<AuditLogPageResponseDTO> getLogs(
      @RequestParam(required = false) String startDate,
      @RequestParam(required = false) String endDate,
      @RequestParam(required = false) String action,
      @RequestParam(required = false) String userId,
      @RequestParam(required = false) String resource,
      @RequestParam(defaultValue = "1") Integer page,
      @RequestParam(defaultValue = "25") Integer size) {
    validatePagination(page, size);
    String sanitizedAction = sanitizeAction(action);
    String sanitizedResource = sanitizeResource(resource);
    LocalDateTime parsedStart = parseDateParam(startDate, false, "startDate");
    LocalDateTime parsedEnd = parseDateParam(endDate, true, "endDate");
    log.debug(
        "Fetching audit logs: startDate={}, endDate={}, action={}, userId={}, resource={}, page={}, size={}",
        parsedStart,
        parsedEnd,
        sanitizedAction,
        userId,
        sanitizedResource,
        page,
        size);
    return ResponseEntity.ok(
        auditService.getLogs(parsedStart, parsedEnd, sanitizedAction, userId, sanitizedResource, page, size));
  }

  @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_AUDITOR')")
  @GetMapping("/logs/{id}")
  public ResponseEntity<AuditLogEntryDTO> getLogById(@PathVariable String id) {
    String sanitizedId = validateAndSanitizeId(id);
    log.debug("Fetching audit log by ID: {}", sanitizedId);
    return ResponseEntity.ok(auditService.getLogById(sanitizedId));
  }

  private void validatePagination(Integer page, Integer size) {
    if (page != null && page < 1) {
      throw new InvalidDataException("page must be greater than or equal to 1", "page", page);
    }
    if (size != null && (size < 1 || size > MAX_PAGE_SIZE)) {
      throw new InvalidDataException("size must be between 1 and " + MAX_PAGE_SIZE, "size", size);
    }
  }

  private String sanitizeAction(String action) {
    if (!StringUtils.hasText(action)) {
      return null;
    }
    String sanitized = action.trim().toUpperCase();
    if (!sanitized.matches("^(CREATE|UPDATE|DELETE|VIEW|LOGIN|LOGOUT|EXPORT)$")) {
      throw new InvalidDataException(
          "Invalid action value. Allowed: CREATE, UPDATE, DELETE, VIEW, LOGIN, LOGOUT, EXPORT",
          "action",
          action);
    }
    return sanitized;
  }

  private String sanitizeResource(String resource) {
    if (!StringUtils.hasText(resource)) {
      return null;
    }
    String sanitized = resource.trim().replaceAll("[;'"]", "");
    if (sanitized.length() > 128) {
      sanitized = sanitized.substring(0, 128);
    }
    return sanitized;
  }

  private String validateAndSanitizeId(String id) {
    if (!StringUtils.hasText(id)) {
      throw new InvalidDataException("id is required", "id", id);
    }
    String trimmed = id.trim();
    if (!trimmed.matches("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")) {
      throw new InvalidDataException("Invalid id format. Expected UUID", "id", id);
    }
    return trimmed;
  }

  private LocalDateTime parseDateParam(String value, boolean endOfDay, String fieldName) {
    if (!StringUtils.hasText(value)) {
      return null;
    }
    try {
      return LocalDateTime.parse(value.trim());
    } catch (DateTimeParseException ex) {
      try {
        LocalDate date = LocalDate.parse(value.trim());
        return endOfDay ? date.atTime(LocalTime.MAX) : date.atStartOfDay();
      } catch (DateTimeParseException nestedEx) {
        throw new InvalidDataException(
            "Invalid " + fieldName + " format. Use ISO date-time or yyyy-MM-dd", fieldName, value);
      }
    }
  }
}
