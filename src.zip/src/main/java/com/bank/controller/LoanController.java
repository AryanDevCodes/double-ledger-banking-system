package com.bank.controller;

import com.bank.dto.loan.LoanDTO;
import com.bank.entity.Loan;
import com.bank.repository.LoanRepository;
import com.bank.service.mapper.LoanMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loans")
@RequiredArgsConstructor
public class LoanController {
    private final LoanRepository loanRepository;
    private final LoanMapper loanMapper;

    @GetMapping("/customer/{customerId}")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_MANAGER', 'ROLE_USER')")
    public ResponseEntity<List<LoanDTO>> getLoansByCustomer(@PathVariable String customerId) {
        List<Loan> loans = loanRepository.findByCustomerId(customerId);
        List<LoanDTO> dtos = loans.stream()
            .map(loanMapper::toDTO)
            .toList();
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/account/{accountId}")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_MANAGER', 'ROLE_USER')")
    public ResponseEntity<List<LoanDTO>> getLoansByAccount(@PathVariable Long accountId) {
        List<Loan> loans = loanRepository.findByAccountId(accountId);
        List<LoanDTO> dtos = loans.stream()
            .map(loanMapper::toDTO)
            .toList();
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{loanId}")
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_MANAGER', 'ROLE_USER')")
    public ResponseEntity<LoanDTO> getLoan(@PathVariable Long loanId) {
        return loanRepository.findById(loanId)
            .map(loan -> ResponseEntity.ok(loanMapper.toDTO(loan)))
            .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ROLE_ADMIN', 'ROLE_MANAGER')")
    public ResponseEntity<LoanDTO> createLoan(@RequestBody LoanDTO loanDTO) {
        // Implementation for creating loan
        return ResponseEntity.ok(loanDTO);
    }
}
