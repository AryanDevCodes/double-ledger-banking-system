package com.bank.dto.auth;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BankSelectionDTO {
  private String bankName;
  private String ifscCode;
  private String bankId;
  private int accountCount;
}
