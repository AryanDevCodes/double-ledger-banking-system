package com.bank.repository;

import com.bank.dto.transaction.TransactionResponseDTO;
import com.bank.entity.Transaction;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
        @Query("select t from Transaction t where "
                        + "(t.senderAccountNumber = :accountNumber and t.senderEmail = :email) "
                        + "or (t.receiverAccountNumber = :accountNumber and t.receiverEmail = :email) "
                        + "order by t.transactionDate desc")
        List<Transaction> findTransactionByAccountNumberAndEmail(
                        @Param("accountNumber") String accountNumber, @Param("email") String email);

        @Query("SELECT t FROM Transaction t "
                        + "LEFT JOIN FETCH t.senderAccount sa "
                        + "LEFT JOIN FETCH sa.customer sc "
                        + "LEFT JOIN FETCH t.receiverAccount ra "
                        + "LEFT JOIN FETCH ra.customer rc "
                        + "WHERE (t.senderAccountNumber = :accountNumber AND t.senderEmail = :email) "
                        + "OR (t.receiverAccountNumber = :accountNumber AND t.receiverEmail = :email) "
                        + "ORDER BY t.transactionDate DESC")
        List<Transaction> findTransactionByAccountNumberAndEmailWithDetails(
                        @Param("accountNumber") String accountNumber, @Param("email") String email);

        @Query("SELECT DISTINCT t FROM Transaction t "
                        + "LEFT JOIN FETCH t.senderAccount sa "
                        + "LEFT JOIN FETCH sa.customer sc "
                        + "LEFT JOIN FETCH sa.bank sb "
                        + "LEFT JOIN FETCH t.receiverAccount ra "
                        + "LEFT JOIN FETCH ra.customer rc "
                        + "LEFT JOIN FETCH ra.bank rb "
                        + "WHERE ((t.senderAccountNumber = :accountNumber AND t.senderEmail = :email AND t.senderBankName = :bankName) "
                        + "OR (t.receiverAccountNumber = :accountNumber AND t.receiverEmail = :email AND t.receiverBankName = :bankName)) "
                        + "ORDER BY t.transactionDate DESC")
        List<Transaction> findTransactionByAccountNumberAndEmailAndBankNameWithDetails(
                        @Param("accountNumber") String accountNumber,
                        @Param("email") String email,
                        @Param("bankName") String bankName);

        List<TransactionResponseDTO> findByTransactionId(Long transactionId);

        Optional<Transaction> findTransactionByTransactionId(Long transactionId);

        @Query("SELECT t FROM Transaction t "
                        + "LEFT JOIN FETCH t.senderAccount sa "
                        + "LEFT JOIN FETCH sa.customer sc "
                        + "LEFT JOIN FETCH t.receiverAccount ra "
                        + "LEFT JOIN FETCH ra.customer rc")
        List<Transaction> findAllWithDetails();

        @Query("SELECT DISTINCT t FROM Transaction t "
                        + "LEFT JOIN FETCH t.senderAccount sa "
                        + "LEFT JOIN FETCH sa.customer sc "
                        + "LEFT JOIN FETCH sa.bank sb "
                        + "LEFT JOIN FETCH t.receiverAccount ra "
                        + "LEFT JOIN FETCH ra.customer rc "
                        + "LEFT JOIN FETCH ra.bank rb "
                        + "WHERE t.senderBankName = :bankName OR t.receiverBankName = :bankName "
                        + "ORDER BY t.transactionDate DESC")
        List<Transaction> findAllWithDetailsByBankName(@Param("bankName") String bankName);
}
