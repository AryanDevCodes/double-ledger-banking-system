package com.bank.security;

public final class SelectedBankContext {
    private static final ThreadLocal<String> SELECTED_BANK = new ThreadLocal<>();

    private SelectedBankContext() {
    }

    public static void set(String selectedBank) {
        if (selectedBank == null || selectedBank.isBlank()) {
            SELECTED_BANK.remove();
            return;
        }
        SELECTED_BANK.set(selectedBank);
    }

    public static String get() {
        return SELECTED_BANK.get();
    }

    public static void clear() {
        SELECTED_BANK.remove();
    }
}