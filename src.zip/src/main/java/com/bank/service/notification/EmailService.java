package com.bank.service.notification;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * Sends application e-mails. When {@code app.mail.enabled=false} (the default) the message is
 * logged at WARN level instead of being delivered, which keeps local development simple while
 * still letting the rest of the flow be exercised.
 */
@Service
@Slf4j
public class EmailService {

  private final JavaMailSender mailSender;

  @Value("${app.mail.enabled:false}")
  private boolean enabled;

  @Value("${app.mail.from:no-reply@bank.local}")
  private String from;

  @Value("${app.mail.reset-link-base:http://localhost:5173/reset-password}")
  private String resetLinkBase;

  @Autowired(required = false)
  public EmailService(JavaMailSender mailSender) {
    this.mailSender = mailSender;
  }

  public void sendPasswordResetEmail(String toEmail, String username, String token) {
    if (toEmail == null || toEmail.isBlank() || token == null || token.isBlank()) {
      return;
    }
    String link = resetLinkBase + "?token=" + token;
    String subject = "Reset your bank account password";
    String body =
        "Hello "
            + (username == null ? "" : username)
            + ",\n\n"
            + "We received a request to reset your password. Use the link below to choose a new"
            + " password. This link will expire in 15 minutes.\n\n"
            + link
            + "\n\nIf you did not request this, you can safely ignore this email.\n\n"
            + "— Bank Security Team";

    if (!enabled || mailSender == null) {
      log.warn(
          "[mail-disabled] would send password reset email to={} subject={} link={}",
          toEmail,
          subject,
          link);
      return;
    }

    try {
      SimpleMailMessage msg = new SimpleMailMessage();
      msg.setFrom(from);
      msg.setTo(toEmail);
      msg.setSubject(subject);
      msg.setText(body);
      mailSender.send(msg);
      log.info("Sent password reset email to {}", toEmail);
    } catch (Exception ex) {
      log.error("Failed to send password reset email to {}", toEmail, ex);
    }
  }
}
