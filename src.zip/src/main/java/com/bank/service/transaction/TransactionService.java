package com.bank.service.transaction;

import com.bank.dto.transaction.TransactionRequestDTO;
import com.bank.dto.transaction.TransactionResponseDTO;
import java.util.List;

public interface TransactionService {
  TransactionResponseDTO makeTransaction(TransactionRequestDTO transactionRequestDTO);

  List<TransactionResponseDTO> getAllTransactions(String accountNumber, String email);

  List<TransactionResponseDTO> getAllTransactionsWithoutFilter();

  List<TransactionResponseDTO> getTransactionsForUser(Long userId);

  List<TransactionResponseDTO> getTransactionsForCustomer(String customerId);

  /**
   * Reverse a previously COMPLETED transaction by posting compensating ledger
   * entries.
   */
  TransactionResponseDTO reverseTransaction(Long transactionId, String reason);
}
