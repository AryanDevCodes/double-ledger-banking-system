ALTER TABLE IF EXISTS transactions
  DROP CONSTRAINT IF EXISTS transactions_status_check;

ALTER TABLE IF EXISTS transactions
  ADD CONSTRAINT transactions_status_check
  CHECK (status IN ('INITIATED', 'COMPLETED', 'FAILED', 'REVERSED'));
